# 直接上传步骤（选择一种执行）

## 选项 A：用 Token（最快，需要你提供 Token）
# 1. 在 https://github.com/settings/tokens 创建 Token (classic)，勾选 repo
# 2. 把下面的 YOUR_TOKEN 替换成真实 Token，执行：
git remote set-url origin https://hgl011091:YOUR_TOKEN@github.com/hgl011091/dsh-im-connect-weixin.git
git push -u origin main

## 选项 B：网页上传（不需要 Token，手动）
# 1. 浏览器新建 https://github.com/new → dsh-im-connect-weixin (Public)
# 2. 打开 D:\HarnessProjects\dsh-im-connect-weixin，压缩整个文件夹
# 3. 在新仓库点击 "uploading an existing file" → 选 zip → 提交

## 选项 C：已准备的本地命令（需要先创建空仓库）
cd D:\HarnessProjects\dsh-im-connect-weixin
git branch -M main
git remote set-url origin https://github.com/hgl011091/dsh-im-connect-weixin.git
git push -u origin main
