import type { ChannelId } from '../engine/session-id.js'

export type ChannelKind = 'qr' | 'credentials' | 'qr-or-credentials'

export interface ChannelField {
  key: string
  label: string
  secret?: boolean
}

export interface ChannelMeta {
  id: ChannelId
  label: string
  description: string
  kind: ChannelKind
  fields: ChannelField[]
}

/** 设置页卡片顺序。 */
export const CHANNEL_ORDER: ChannelId[] = [
  'weixin',
]

export const CHANNEL_META: Record<ChannelId, ChannelMeta> = {
  weixin: {
    id: 'weixin',
    label: '微信',
    description: '通过微信机器人接收并回复用户消息',
    kind: 'qr',
    fields: [],
  },
}

export function listChannelMeta(): ChannelMeta[] {
  return CHANNEL_ORDER.map((id) => CHANNEL_META[id])
}

export function supportsQr(id: ChannelId): boolean {
  const kind = CHANNEL_META[id]?.kind
  return kind === 'qr' || kind === 'qr-or-credentials'
}