import type { ChannelAdapter } from '../engine/types.js'
import type { ChannelId } from '../engine/session-id.js'
import { createWeixinChannel } from './weixin.js'

export function createChannelAdapter(
  id: ChannelId,
  config: Record<string, string>,
  log: (line: string) => void,
  stateDir: string,
  options?: { accountId?: string; accountLabel?: string; host?: { get(name: string): unknown }; onWeixinBotToken?: (token: string | undefined) => void | Promise<void> },
): ChannelAdapter | undefined {
  if (id !== 'weixin') return undefined
  const adapter = createWeixinChannel({ enabled: true, stateDir, botToken: config.botToken, onBotToken: options?.onWeixinBotToken, host: options?.host }, log, stateDir)
  if (!adapter) return undefined
  return {
    ...adapter,
    id: options?.accountId ?? adapter.id,
    label: options?.accountLabel ?? adapter.label,
  }
}