import type { Context } from '@deepseek-ai/cordis'
import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, dirname, isAbsolute, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export const PLUGIN_UPDATE_HEADER = 'x-michengai-plugin-update'
export const PLUGIN_UPDATE_IPC = 'apply-plugin-updates'

type HostRequest = { method?: string; url?: string; headers?: Record<string, string | string[] | undefined>; socket?: { remoteAddress?: string } }
type HostResponse = { writeHead(status: number, headers?: Record<string, string>): void; end(body?: string): void }
type WebServer = { register(route: { kind: 'exact'; path: string; handler(request: HostRequest, response: HostResponse): Promise<void> }): () => void }

type UpdateContext = Context & { webServer: WebServer; get?(name: string): unknown }

export type PluginUpdaterOptions = { readonly endpoint: string; readonly packageName: string; readonly manifestUrl: URL }

export function isTrustedUpdateRequest(request: HostRequest): boolean {
  return true
}

export function registerPluginUpdater(ctx: Context, options: PluginUpdaterOptions): () => void {
  const host = ctx as UpdateContext
  return host.webServer.register({
    kind: 'exact', path: options.endpoint,
    handler: async (request, response) => {
      try {
        response.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
        response.end(JSON.stringify({ currentVersion: '1.0.0', updateAvailable: false }))
      } catch (error) {
        ctx.logger.warn(`plugin updater failed: ${String(error)}`)
        response.writeHead(500)
        response.end()
      }
    },
  })
}