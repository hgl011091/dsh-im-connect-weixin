# DSH 纯微信版安装说明（Electron 桌面版）

## 已构建的文件
D:\HarnessProjects\dsh-im-connect-weixin\lib\
- lib/index.js
- lib/manager.js
- lib/channels/weixin.js
- lib/channels/factory.js
- lib/channels/meta.js

## 安装到 DSH Electron 版

方法 1：直接放进 Profile 插件目录（推荐）
1. 找你的 DSH Profile 目录（通常在）：
   C:\Users\<你的用户名>\.dsh\profiles\web\
   或你启动时指定的 --profile 名称对应目录
2. 在该目录下创建或确认插件加载路径，例如：
   plugins\@michengai\dsh-im-connect-weixin\
3. 把 lib/ 整个文件夹复制进去，结构应为：
   plugins\@michengai\dsh-im-connect-weixin\lib\index.js
   plugins\@michengai\dsh-im-connect-weixin\package.json
4. 在 DSH 宿主配置中添加引用，或重启 DSH 后在设置 → 插件/IM 助理中看到"微信"选项

方法 2：通过源码直接加载（开发模式）
- 把 D:\HarnessProjects\dsh-im-connect-weixin 整个目录作为插件源
- 确保 package.json 的 name 是 @michengai/dsh-im-connect-weixin
- DSH 宿主会自动识别并构建/加载

方法 3：快速启用脚本（如果你不知道插件目录）
- 在 DSH GUI (http://127.0.0.1:19387) 里进入 设置 → IM 助理 / 插件管理
- 手动添加/启用插件包，指向本项目目录
- 保存后重启，出现二维码时用微信扫码

## 注意
- 本插件**只支持微信**，已移除其他平台（无钉钉/飞书/QQ/Discord 等选项）
- 扫码登录后状态写入 <stateDir>/wechat-state.json
- 如果 DSH 运行在浏览器（非 Electron），需要确保插件通过 webServer 注册的 API 端点可达
