/** 微信 iLink 扫码登录。 */
export function weixinHeaders(uin = Buffer.from(String(Math.floor(Math.random() * 0xffffffff)), 'utf8').toString('base64')): Record<string, string> {
  return {
    'content-type': 'application/json',
    'iLink-App-ClientVersion': '1',
    'X-WECHAT-UIN': uin,
  }
}

export function parseWeixinQr(body: unknown): { qrcodeId: string; qrUrl: string } {
  const record = body as Record<string, unknown>
  const qrcodeId = (record.qrcode ?? record.qrcode_id ?? '') as string
  const qrUrl = (record.qrcode_img_content ?? record.qrcode_url ?? record.url ?? '') as string
  if (!qrcodeId || !qrUrl) throw new Error('微信二维码字段缺失')
  return { qrcodeId, qrUrl }
}

export function parseWeixinStatus(body: unknown): { status: string; credentials?: Record<string, string> } {
  const record = body as Record<string, unknown>
  const status = String(record.status ?? '')
  if (Number(record.ret ?? 0) === 0 && status === 'confirmed') {
    const botToken = String(record.bot_token ?? '')
    const allowedUserId = String(record.ilink_user_id ?? '')
    const baseUrl = String(record.baseurl ?? record.base_url ?? '')
    if (!botToken) throw new Error('微信确认登录但缺少 token')
    const credentials: Record<string, string> = { botToken, bound: '1' }
    if (allowedUserId) credentials.allowedUserId = allowedUserId
    if (baseUrl) credentials.baseUrl = baseUrl
    return { status: 'success', credentials }
  }
  if (status === 'expired') return { status: 'expired' }
  if (status === 'scaned' || status === 'scanned') return { status: 'scanned' }
  return { status: 'waiting' }
}

export async function beginWeixinQr(signal?: AbortSignal): Promise<{ qrUrl: string; expiresAt: number; pollIntervalMs: number; poll: (pollSignal?: AbortSignal) => Promise<{ status: string; credentials?: Record<string, string> }> }> {
  const headers = weixinHeaders()
  const res = await fetch('https://ilinkai.weixin.qq.com/ilink/bot/get_bot_qrcode?bot_type=3', {
    method: 'POST', headers, body: '{}', signal: signal ?? AbortSignal.timeout(15_000),
  })
  if (!res.ok) throw new Error(`微信二维码 HTTP ${res.status}`)
  const data = await res.json() as Record<string, unknown>
  const begun = parseWeixinQr(data)
  return {
    qrUrl: begun.qrUrl,
    expiresAt: Date.now() + 5 * 60_000,
    pollIntervalMs: 2000,
    poll: async (pollSignal?: AbortSignal) => {
      const pollRes = await fetch(`https://ilinkai.weixin.qq.com/ilink/bot/get_qrcode_status?qrcode=${encodeURIComponent(begun.qrcodeId)}`, {
        method: 'POST', headers, body: '{}', signal: pollSignal ?? AbortSignal.timeout(40_000),
      })
      if (!pollRes.ok) throw new Error(`微信状态 HTTP ${pollRes.status}`)
      return parseWeixinStatus(await pollRes.json())
    }
  }
}