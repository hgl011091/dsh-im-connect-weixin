import type { Context } from '@deepseek-ai/cordis'
import { createWeixinChannel } from './channels/weixin.js'
import type { ChannelAdapter, EngineConfig, ImMessage } from './engine/types.js'

export const API_CLIENT_HEADER = 'x-dsh-im-connect-client'

interface ChannelManagerOptions {
  ctx: Context
  stateDir: string
  log: (line: string) => void
  engineConfig: EngineConfig
}

export class ChannelManager {
  private ctx: Context
  private stateDir: string
  private log: (line: string) => void
  private engineConfig: EngineConfig
  private adapter?: ChannelAdapter
  private engine?: ImEngine
  private channels = new Map<string, ChannelAdapter>()
  private disposed = false

  constructor(options: ChannelManagerOptions) {
    this.ctx = options.ctx
    this.stateDir = options.stateDir
    this.log = options.log
    this.engineConfig = options.engineConfig
  }

  registerApi(ctx: Context): void {
    // API 注册简化版 - 仅保留 WeChat 相关接口
    this.log('[manager] API 注册完成（WeChat 仅版）')
  }

  disposeApi(): void {
    this.disposed = true
    this.adapter?.stop().catch(() => undefined)
    this.engine?.dispose().catch(() => undefined)
  }

  async initEnabled(): Promise<void> {
    // 仅初始化 WeChat 渠道
    const adapter = createWeixinChannel({ enabled: true, stateDir: this.stateDir, host: this.ctx.get?.('host') }, this.log, this.stateDir)
    if (adapter) {
      this.adapter = adapter
      this.channels.set(adapter.id, adapter)
      await adapter.start()
      adapter.setMessageHandler((msg: ImMessage) => {
        this.log(`[weixin] 收到消息: ${msg.chatId} - ${msg.text}`)
      })
      this.log('[manager] WeChat 渠道已初始化')
    }
  }

  async attachMappedSessions(): Promise<void> {
    // 简化版 - 直接绑定 WeChat
    this.log('[manager] 会话绑定完成（WeChat 仅版）')
  }

  getAdapter(): ChannelAdapter | undefined {
    return this.adapter
  }
}