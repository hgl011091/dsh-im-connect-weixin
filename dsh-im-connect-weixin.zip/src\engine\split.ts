/** 长文分片：按渠道上限切分，尽量保持 Markdown 结构完整。 */
export function splitText(text: string, max: number): string[] {
  if (max <= 0 || text === '') return text === '' ? [] : [text]
  const chunks: string[] = []
  let remaining = text
  while (remaining.length > max) {
    const cut = remaining.lastIndexOf('\n', max)
    if (cut === -1) {
      chunks.push(remaining.slice(0, max))
      remaining = remaining.slice(max)
    } else {
      chunks.push(remaining.slice(0, cut))
      remaining = remaining.slice(cut + 1)
    }
  }
  if (remaining) chunks.push(remaining)
  return chunks
}