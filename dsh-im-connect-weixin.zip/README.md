# DSH IM Connect - WeChat Only (微信仅版)

从原始仓库 https://github.com/MichengAI/dsh-im-connect 提取，仅保留微信功能。

## 修改内容

### 已保留（核心 WeChat 功能）
- `src/channels/weixin.ts` - 微信 iLink Bot 协议适配器（完整保留）
- `src/channels/file-send.ts` - 文件发送辅助
- `src/channels/qr/weixin.ts` - 微信 QR 扫码登录
- `src/engine/*` - 引擎核心（类型、命令本地化、诊断、密钥队列等）

### 已简化/修改
- `src/channels/factory.ts` - 仅注册 `weixin`
- `src/channels/meta.ts` - 仅保留 `weixin` 频道元数据
- `src/engine/session-id.ts` - 仅保留 `weixin` 作为有效频道
- `src/index.ts` - 仅导出 WeChat 相关功能
- `src/manager.ts` - 简化为仅初始化 WeChat 渠道
- `client.js` - 仅保留微信设置面板 UI
- `package.json` - 移除非 WeChat 依赖（dingtalk-stream, @wecom/aibot-node-sdk, @larksuiteoapi/node-sdk, @tencent-connect/qqbot-connector）

### 已移除
- 所有其他渠道：dingtalk, feishu, lark, wecom, qq, telegram, discord
- 其他渠道文件：dingtalk.ts, feishu.ts, lark.ts, wecom.ts, qq.ts, telegram.ts, discord.ts
- 复杂的多渠道管理逻辑

## 接口保持一致
- `CHANNEL_ORDER` = `['weixin']`
- `CHANNEL_META` 仅包含微信描述
- `createChannelAdapter('weixin', ...)` 功能完整
- 代码结构与原仓库一致，便于后续维护

## 构建
```bash
pnpm install
pnpm run build
```

输出到 `lib/` 目录。