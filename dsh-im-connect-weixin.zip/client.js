/**
 * dsh-im-connect 浏览器端：IM助理设置页 + 工作区频道槽 - WeChat Only.
 */
window.__ModuleLoader__.load({
  id: "@michengai/dsh-im-connect-weixin",
  factory: (require) => {
    var React = require("react");
    const { useState, useEffect } = React;
    const primitives = require("@deepseek-ai/dsh-client-ui-primitives");
    const Button = primitives.Button || function Button(props) { return React.createElement("button", { type: "button", className: props && props.className, disabled: props && props.disabled, onClick: props && props.onClick }, props && props.children); };
    const Modal = primitives.Modal || function Modal() { return null; };
    
    // WeChat Only - Simplified UI showing only WeChat connection status
    function WeChatSettingsPanel() {
      const [loginStatus, setLoginStatus] = useState('未登录');
      const [qrUrl, setQrUrl] = useState('');
      
      useEffect(() => {
        // Initialize WeChat status
        setLoginStatus('等待扫码');
      }, []);
      
      return React.createElement("div", { className: "wechat-settings-panel", style: { padding: 24, maxWidth: 600 } },
        React.createElement("h2", null, "微信 (WeChat) 连接"),
        React.createElement("p", { style: { color: '#666' } }, "通过微信机器人接收并回复用户消息"),
        React.createElement("div", { style: { padding: 16, background: '#f5f5f5', borderRadius: 8, marginTop: 16 } },
          React.createElement("h3", null, "连接状态"),
          React.createElement("p", { style: { fontWeight: 'bold', color: loginStatus === '已登录' ? 'green' : '#d4a017' } }, loginStatus),
          qrUrl && React.createElement("div", { style: { marginTop: 12 } },
            React.createElement("p", null, "请使用微信扫码登录:"),
            React.createElement("img", { src: qrUrl, alt: "二维码", style: { maxWidth: 200, border: '1px solid #ddd', padding: 8 } })
          ),
          React.createElement("div", { style: { marginTop: 16, display: 'flex', gap: 8 } },
            React.createElement(Button, { onClick: () => setLoginStatus('已登录（自动恢复）'), disabled: false }, "模拟登录"),
            React.createElement(Button, { onClick: () => { setLoginStatus('已停止'); setQrUrl(''); }, disabled: false }, "停止")
          )
        )
      );
    }
    
    return {
      WeChatSettingsPanel: WeChatSettingsPanel,
      CHANNEL_ORDER: ['weixin'],
      CHANNEL_META: {
        weixin: {
          id: 'weixin',
          label: '微信',
          description: '通过微信机器人接收并回复用户消息',
          kind: 'qr',
          fields: []
        }
      }
    };
  }
});